Baseado no projeto "zuul-better" dos autores Michael Kolling and David J. Barnes, que faz parte do material do livro:
{Objects First with Java - A Practical Introduction using BlueJ dos mesmos 
David J. Barnes and Michael Kolling
Pearson Education, 2002}

Implementado com ajuda do "chatGPT" e traduzido por:
Breno de Jesus Silva
Universidade Federal de Sergipe
Graduando em Ciência da computação
05/04/2023.


