public class Principal {
    public static void main(String[] args){
        Game game = new Game();
        game.play();
        
    }
}